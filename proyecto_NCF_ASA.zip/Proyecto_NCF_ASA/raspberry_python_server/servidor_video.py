from time import sleep
import socket
from picamera import PiCamera
import zipfile

camera= PiCamera()
camera.resolution=(320,240)
camera.start_preview() 
servidor= socket.socket(socket.AF_INET,socket.SOCK_STREAM)
servidor.bind(('192.168.1.100',4008))
servidor.listen(1)

while True:
	cliente, addr= servidor.accept()
	print 'Conectados con', addr
	while True:
		camera.capture('foto.jpg')
		fotozip=zipfile.ZipFile('fotograma.zip','w')
		fotozip.write('foto.jpg',compress_type=zipfile.ZIP_DEFLATED)
		fotozip.close()
		manf1=open('fotograma.zip')
		bytes=manf1.read()
		numbytes=len(bytes)
		aviso=str(numbytes)
		while len(aviso)!=10:
			aviso='0'+aviso

		cliente.send(aviso)
		cliente.send(bytes)
		recibido=cliente.recv(1)
		if recibido=='':
			break
	print 'Fin de la conexion'
	cliente.close()

