import time
import RPi.GPIO as GPIO
import socket

#Conexion TCP/IP con Matlab para configurar posicion de los motores
servidor_motores=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
servidor_motores.bind(('192.168.1.100',5008)) #192.168.1.100//192.168.137.175 
servidor_motores.listen(1)

#Configuracion de los servomotores
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)
pitch=12
yaw=37
GPIO.setup(12,GPIO.OUT)
GPIO.setup(37,GPIO.OUT)
p=GPIO.PWM(pitch,50)
w=GPIO.PWM(yaw,50)
p.start(4)
w.start(7.5)
while True:
	cliente_motores,addr=servidor_motores.accept()
	print 'Conectados con: ',addr
	flag=1
	while flag==1:
		datos=''
		while len(datos)!=4:
			leido=cliente_motores.recv(4)
			if leido=='':
				flag=0
				break
			datos=datos+leido
		if flag==1:
			p.ChangeDutyCycle(float(datos))

        	datos=''
        	while len(datos)!=4 and flag==1:
                	datos=datos+cliente_motores.recv(4)
        	if flag==1:
			w.ChangeDutyCycle(float(datos))
	print 'Fin de la conexion'
	cliente_motores.close()
