<?php 	
	
	require "funciones_festify.php";
	
	session_start();

	$message = '';
		
	$conn2 = new mysqli("localhost", "root", "", "usuarios_festify") ;
	$conn2->set_charset("utf8");
		
	if ($conn2->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
		
	if (!empty($_POST['nombre']) && !empty($_POST['apellidos']) && !empty($_POST['correo']) && !empty($_POST['passwd']) && !empty($_POST['passwdACK'])) {
			
		// 1º paso: Comprobar que el correo no está ya en uso.
		
		$no_registrado = true;
		
		$consulta= "SELECT*FROM datos_usuarios";
		$result = $conn2->query($consulta);
	  
		while ($columnas =mysqli_fetch_array($result)){
			
			if ($columnas ["correo"] == $_POST['correo']){
				
				$no_registrado = false;
				$message = 'Error: email indicado ya en uso. Por favor, seleccione otro.';
			}								
		}
		
		// 2º paso: Comprobar que se ha repetido bien la contraseña.
		$coinciden = true;
		
		if ($_POST['passwd'] != $_POST['passwdACK']){ // Cuidado con las llaves que el compilador no da error !!!!!!!!!!!!
			
			$coinciden = false;
			$message = 'Error: las contraseñas no coinciden.';
		}
		
		// Si el correo no está en uso, almacena datos en la db
		
 		if ($no_registrado && $coinciden) { 
					
			require 'database.php' ;
			
			$sql = ' INSERT INTO datos_usuarios (nombre, apellidos, correo, passwd, passwd_cd) VALUES (:nombre, :apellidos, :correo, :passwd, :passwd_cd) ' ;					
			$stmt = $conn -> prepare($sql) ; // La variable $conn viene del archivo 'database.php'
					
			$stmt->bindParam(':correo', $_POST['correo']);
			$stmt->bindParam(':nombre', $_POST['nombre']);
			$stmt->bindParam(':apellidos', $_POST['apellidos']);
			$stmt->bindParam(':passwd', $_POST['passwd']);
			$password = password_hash($_POST['passwd'], PASSWORD_BCRYPT);
			$stmt->bindParam(':passwd_cd', $password);

			if ($stmt->execute()) {
				
				$_SESSION['signupMsg'] = 'Usuario registrado con éxito!';
				
				// Enviar correo !
				$msg = "Su registro en FESTIFY se ha completado satisfactoriamente. \n \nPor favor, no conteste a este mensaje.\n" ;
				
				enviaCorreo($_POST['correo'], 'FESTIFY: Registro en FESTIFY completado', $msg);
				
				header('Location: index.php');
				
			} else {
				$message = 'Sorry there must have been an issue creating your account';
			}
			
		}	
	
	}
?>

<!DOCTYPE html>

<html>
	<head>
		<title>REGISTRO</title>
		<meta charset = "utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="CSS/formato_registro.css">
		<link rel="shortcut icon" href="logo.png">
	</head>


<body>
		<font color='red'>
		<?php if(!empty($message)): ?>
				<p> <?= $message ?></p> 
		<?php endif; ?>
		</font>
		
		</br>
		<h1> <img src= "logo.png" width = 80px/ align = center>
		FESTIFY
		</h1>
		
		<hr size="2px" color="gray" />
		
		<form action="2_REGISTRO.php" name="formulario" method="POST">
			
			&nbsp &nbsp &nbsp
			Nombre: &nbsp
			
			<input type="text" name ="nombre" class="campo" placeholder="¿Cómo quieres que te llamemos?*" required/>
			</br></br> &nbsp &nbsp 
			
			Apellidos: &nbsp
			<input type="text" name ="apellidos" class="campo" placeholder="Apellidos*" required/>
			<br/></br> &nbsp &nbsp &nbsp &nbsp &nbsp
			
			E-mail: &nbsp 
			<input type="email" name ="correo" class="campo" placeholder="Tu correo electrónico*" required/>
			</br></br>
			
			Contraseña: &nbsp 
			<input type="password" name ="passwd" class="campo" id="passwd" placeholder="Escriba una contraseña para su cuenta*" required/>
			</br></br> &nbsp &nbsp &nbsp
			
			Verificar: &nbsp
			<input type="password" name ="passwdACK" class="campo" id="passwdACK" placeholder="Repita la contraseña*" required/> <!-- contraseña codificada -->
			</br></br> 

			<center>
			&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
			<input type="submit" value="Enviar datos">
			<p class="message">¿Ya estás registrado? <a href="index.php">¡Accede a la fiesta!</a></p>
			</center>
			
		</form>
		</br></br>
		</br></br>

</body>
</html>
