<?php
	session_start();
	
	$conn2 = new mysqli("localhost", "root", "", "playlist") ;
	$conn2->set_charset("utf8");
		
		if ($conn2->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 
	
		$consulta= "SELECT*FROM canciones_disponibles";
		$result = $conn2->query($consulta);
		 
		if (!empty($_POST['buscar']))
		{
			$flag = 0;
			$flag2 = 0;
			while ($fila=mysqli_fetch_array($result))
			{
				if (strcasecmp($fila["Cancion"], $_POST['buscar']) == 0)
				{
					$flag = 1;
					foreach($_SESSION["Canciones"] as $comprueba)
					{
						if (strcmp($comprueba, $_POST['buscar']) == 0)
						{
							$flag2 = 1;
						}
					}
					if($flag2==0)
					{
						array_push($_SESSION["Canciones"], $fila["Cancion"]);
						array_push($_SESSION["Artistas"], $fila["Artista"]);
						array_push($_SESSION["Imagenes"], $fila["IMagenes"]);
					}
				}
			}
		}
		$longitud = sizeof($_SESSION["Canciones"]);
		
		for ($i=1; $i<$longitud; $i++)
			{
				if (isset($_POST[$i . "_x"]))  /* Si se pulsa el corazón correspondiente... cambio orden - subo canción*/
				{
						$_SESSION["flag_submit"][$i] = 0;
						$aux = $_SESSION["Canciones"][$i];
						$_SESSION["Canciones"][$i] = $_SESSION["Canciones"][$i-1];
						$_SESSION["Canciones"][$i-1] = $aux;
						
						$aux = $_SESSION["Artistas"][$i];
						$_SESSION["Artistas"][$i] = $_SESSION["Artistas"][$i-1];
						$_SESSION["Artistas"][$i-1] = $aux;
						
						$aux = $_SESSION["Imagenes"][$i];
						$_SESSION["Imagenes"][$i] = $_SESSION["Imagenes"][$i-1];
						$_SESSION["Imagenes"][$i-1] = $aux;
				}
			}
			
		$canciones = $_SESSION["Canciones"];
		$artistas = $_SESSION["Artistas"];
		$imagenes = $_SESSION["Imagenes"];

?>	

<!DOCTYPE html>
<html>
		
	<head>
		<meta charset = "utf-8">
		<title> THE PARTY </title>
		<link rel="stylesheet" type="text/css" href="CSS/formato_party.css">
		<link rel="shortcut icon" href="logo.png">
	</head>
	
	<body>
	<div id = "mi_cabecera">
		<form action = "index.php" method = "get" >
				<input type ='submit' 
						value="CERRAR SESIÓN"
						class="boton"/>		
		</form>
		&nbsp
		<img class="alineadoTextoImagen" src= "logo.png"  width = 100px/ >
		&nbsp &nbsp <?php echo $_SESSION['usuario_activo']; echo "'s Party"; ?>	
	
		<form action="3_THE_PARTY.php" name= "buscar" method="POST">
			<input type="search" class="buscar" id="miBusqueda" name="buscar" placeholder=" Añadir canción">
			<input type="image" class ="alineadoTextoImagen" src="lupa.png" width=30px />
		</form>
		</br>
	</div>	
			
		<div id= "mi_tabla" style="overflow-y:auto;">		<!-- Barrita deslizadora vertical -->
				
			<table>		
			<?php 
			
			for($i=0; $i<$longitud; $i++)
			{	
				echo "<tr>";
				echo "<td> &nbsp &nbsp"; 
				$image= $imagenes[$i];
			?>
				<img src= "<?php echo $image; ?>" class= 'alineadoTextoImagen'/> 
			<?php 
				echo "&nbsp $canciones[$i] &nbsp &nbsp -- &nbsp &nbsp $artistas[$i] </td>"; ?>
				
				<form method="POST">
				<td class="me_gusta"> &nbsp &nbsp <input type="image" src="me_gusta_2.png" name="<?php echo $i;?>" alt = "Submit" width = 20px/> </td>
				</form>
				<?php echo '</tr>';
			}
			?>
			</table>
		</div>

		</br>
			
		<div id="footer" align="center"> 
			Copyright 2019-2020 AlvaroPilar'sParty.com 
		</div>
	</body>
</html>



