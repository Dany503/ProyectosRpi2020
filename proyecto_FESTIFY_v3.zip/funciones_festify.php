<?php

	function enviaCorreo($to, $asunto, $mensaje) {			
		require 'class.phpmailer.php';
		require 'class.smtp.php';
		
		
		
		$mail = new PHPMailer;
		$mail->CharSet = "utf-8";
		
		
		//Set your existing gmail address as user name
		$mail->Username = 'festify.servicionotificaciones@gmail.com';
		$mail->setFrom('festify.servicionotificaciones@gmail.com', 'Servidores Festify');

		//Set the password of your gmail address here
		$mail->Password = 'deii2MII';
		
		$mail->isHTML(true);
		$mail->addAddress($to);
		$mail->Subject = $asunto;
		$mail->Body = $mensaje;
		$mail->IsSMTP();
		$mail->SMTPSecure = 'tls';
		$mail->Host = 'smtp.gmail.com';
		$mail->SMTPAuth = true;
		$mail->Port = 587;

		
		if($mail->send()) return true; else return false;
		
	
	}	
	
	function TablaColaCanciones($Usuario) 
	{ 
		$conn2 = new mysqli("localhost", "root", "", "playlist") ;
		$conn2->set_charset("utf8");
		
		if ($conn2->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 
	
		$consulta= "SELECT*FROM canciones_disponibles";
		$result = $conn2->query($consulta);
		 
		if (!empty($_POST['buscar']))
		{ 
			$flag = 0;
			while ($fila=mysqli_fetch_array($result))
			{
				if (strcmp($fila["Cancion"], $_POST['buscar']) == 1)
				{
					array_push($_SESSION["Canciones"], $fila["Cancion"]);
					array_push($_SESSION["Artistas"], $fila["Artista"]);
					array_push($_SESSION["Imagenes"], $fila["Imagen"]);
				}
			}
		}
		$canciones = $_SESSION["Canciones"];
		$artistas = $_SESSION["Artistas"];
		$imagenes = $_SESSION["Imagenes"];
		
		echo '<table>';		
			
			/* Genera las filas*/
			$longitud = sizeof($_SESSION["Canciones"]);
			
			for($i=0; $i<$longitud; $i++)
			{	
				echo "<tr>";
				echo "<td> &nbsp &nbsp
					<img src=https://i.scdn.co/image/ab67616d000048510ac6eadf9eea2c3485e6043d class= 'alineadoTextoImagen'/> 
					&nbsp $canciones[$i] &nbsp &nbsp -- &nbsp &nbsp $artistas[$i] </td>";
				echo '<td class="me_gusta"> &nbsp &nbsp <input type="image" src="me_gusta_2.png" alt="Submit" width = 20px/> </td>';
				echo '</tr>';
			}
			
		
		echo "</table>";
	}
?>




 