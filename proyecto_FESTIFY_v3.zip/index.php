<?php 	
	
	session_start();
	
	$_SESSION["lista"] = array("");
	$_SESSION["Canciones"] = array("");
	$_SESSION["Artistas"] = array("");
	$_SESSION["Imagenes"] = array("");
	
	$_SESSION["flag_submit"] = array_fill(1, 50, 0);
	
	$message = '';

	// ACCESO A UNA FIESTA
	
	$conn2 = new mysqli("localhost", "root", "", "fiestas") ; 
	$conn2->set_charset("utf8");
		
	if ($conn2->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 	
			
	if (!empty($_POST['join_party'])) { 			// Se ha pulsado el botón de unirse a una fiesta; 
			// hay que comprobar que dicha fiesta existe y, en caso afirmativo, redirigir a la página principal de la misma.
			
		if (!empty($_POST['codigo_fiesta'])) {
			
			$consulta= "SELECT*FROM fiestas_creadas";
			$result = $conn2->query($consulta);
		  
			while ($columnas =mysqli_fetch_array($result)){

				if ($columnas ["codigo_fiesta"] == $_POST['codigo_fiesta']){ // La fiesta existe
					
					$_SESSION["usuario_activo"] = $columnas["admin"] ; // Hay que pasar por aquí sí o sí para acceder a una fiesta.
					$_SESSION["nombre_playlist"] = $columnas["admin"] ;
					$_SESSION["apellido_playlist"] = $columnas["apellido"] ;
					header('Location: 3_THE_PARTY.php');
					
				} else {
					$message = 'Error: La fiesta indicada no existe.';
				}
			}
		} else {
			$message = 'Introduce el código de la fiesta para unirte a ella!';
		}
		
	} elseif (!empty($_POST['create_party'])) { // Se ha pulsado el botón de "CREAR FIESTA"
											// Entonces se exige iniciar sesión para poder crearla.
///										
		$inicio_sesion = false ;
		$error_email = false ;
		$error_pw = false ;

		$conn2 = new mysqli("localhost", "root", "", "usuarios_festify") ;
		$conn2->set_charset("utf8");
			
		if ($conn2->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 
		
		if (!empty($_POST['correo']) && !empty($_POST['passwd'])) { 
			
			$consulta= "SELECT*FROM datos_usuarios";
			$result = $conn2->query($consulta);
		  
			while ($columnas =mysqli_fetch_array($result)){ // Este bucle recorre todas las filas de la base de datos (todos los usuarios que hay).
				
				if ($columnas ["correo"] == $_POST['correo']){ // El correo indicado sí está registrado.
					
					if ($columnas ["passwd"] == $_POST['passwd']){ // contraseña es correcta para ese email.
						
						$inicio_sesion = true ;
						$_POST['nombre'] = $columnas["nombre"] ;
						$_POST['apellido'] = $columnas["apellidos"] ;
						$nombre = $columnas["nombre"] ;
						$apellido = $columnas["apellidos"] ;
						
					} else {
						$error_pw = true ;
					}
				}							
			}
			
			if(!$inicio_sesion && !$error_pw){
				$error_email = true ;
			}
		}

		if ($inicio_sesion) {

			$permitted_chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
			$codigo = substr(str_shuffle($permitted_chars), 0, 6) ;	
			$_POST['fiesta_creada'] = $codigo ;
					
			require 'database2.php' ;
							
			$sql = ' INSERT INTO fiestas_creadas (codigo_fiesta,admin,apellido,correo) VALUES (:fiesta_creada,:admin,:apellido,:correo) ' ;					
			$stmt = $conn -> prepare($sql) ; 
							
			$stmt->bindParam(':fiesta_creada', $_POST['fiesta_creada']);
			$stmt->bindParam(':admin', $_POST['nombre']);
			$stmt->bindParam(':apellido', $_POST['apellido']);
			$stmt->bindParam(':correo', $_POST['correo']);
			

			if ($stmt->execute()) { // La fiesta ha quedado registrada en la db con éxito.
						
				$message = 'El código de su fiesta es: ';
						
			} else {
					
				$message = 'Sorry there must have been an issue creating your party';
				$codigo = '' ;
			}
		} elseif($error_pw && !$error_email){
			$message = 'Error: contraseña incorrecta.';
		} elseif($error_email){
			$message = 'Error: email no registrado.';
		} else {
			$message = 'Para crear una fiesta debes iniciar sesión!';
		}
	}
?>

<!DOCTYPE html>

<html>
		
	<head>
		<title> PARTY ACCESS </title>
		<meta charset = "utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="CSS/formato_inicio.css">
		<link rel="shortcut icon" href="logo.png" width = 200px/ >
		
	</head>
	
	<body>
	
			<font color='yellow'>
			<?php if(!empty($message) && !empty($codigo)): ?>
				<p> <?= $message ?> <?= $codigo ?></p> 
			<?php elseif(!empty($message)): ?>
				<p> <?= $message ?> </p> 
			<?php endif; ?>
			</font>

			<img src= "logo.png" width = 150px/ >
			</br> 
			<h1>FESTIFY</h1>
			<h3> Deja que tus invitados elijan </br> la música que sonará en tu fiesta</h3>
			
			<form action="index.php" name="formulario" method="POST">
						
				<p>
					<input type="text" class = "buscador" name ="codigo_fiesta" placeholder = "Código de la fiesta"></br>	
					<input type="submit" name="join_party" class="boton" value="UNIRSE A LA FIESTA"></br>
					<input type="submit" name="create_party" class="boton" value="CREAR FIESTA">
				</p>	
				
				<p>
					<input type="text" name ="correo" class = "buscador" placeholder = "Email"></br>	
					<input type="password" name="passwd" class="buscador" placeholder="Contraseña">
				</p>
				
				<font color='white'>
					<p>
						<a href="2_REGISTRO.php" style="color:white;"> <!-- <a> crea enlace a otra página -->
						¡Regístrate para crear o unirte a una fiesta!
						</a>	
					</p>
				</font>
				
			</form>
	</body>
</html>