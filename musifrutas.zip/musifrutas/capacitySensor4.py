#!/user/bin/env python
# -*- coding: utf-8 -*-
'''

    Before running, install timidity (sudo apt-get install timidity) and run:

    timidity -iA &
    
'''

import RPi.GPIO as GPIO
import pygame
import pygame.midi
from time import sleep
import time

notes=[33,35,36,38,40,41,43,45,47,48,50] #empieza en la, escala menor
#notes=[33,35,37,38,40,42,44,45,47,49,50] #escala mayor

#definimos una matriz donde cada fila es una fruta y; columna 1: pin de entrada; columna 2: pin de salida; columna 3: nota on/off
frutas = [[14,2,False],[15,3,False],[18,4,False],[23,17,False],[24,27,False],[25,22,False],[8,10,False],[7,9,False],[1,11,False],[12,0,False],[16,5,False],[20,6,False],[21,13,False],[19,26,False]]
timeout = 10000
total = 0
GPIO.setmode(GPIO.BCM)		#Numeracion según los pines del chip interno.
#GPIO.setwarnings(False)		#Desactiva los warnings

def CapRead(inPin,outPin):
    total = 0
    
    # set Send Pin Register low
    GPIO.setup(outPin, GPIO.OUT)
    GPIO.output(outPin, GPIO.LOW)
    
    # set receivePin Register low to make sure pullups are off 
    GPIO.setup(inPin, GPIO.OUT)
    GPIO.output(inPin, GPIO.LOW)
    GPIO.setup(inPin, GPIO.IN)
    
    # set send Pin High
    GPIO.output(outPin, GPIO.HIGH)
    
    # while receive pin is LOW AND total is positive value
    while( GPIO.input(inPin) == GPIO.LOW and total < timeout ):
        total+=1
    if ( total > timeout ):
        return -2 # total variable over timeout
        
     # set receive pin HIGH briefly to charge up fully - because the while loop above will exit when pin is ~ 2.5V 
    GPIO.setup( inPin, GPIO.OUT )
    GPIO.output( inPin, GPIO.HIGH )
    GPIO.setup( inPin, GPIO.IN )
    
    # set send Pin LOW
    GPIO.output( outPin, GPIO.LOW )

    # while receive pin is HIGH  AND total is less than timeout
    while (GPIO.input(inPin)==GPIO.HIGH and total < timeout) :
        total+=1
    
    if ( total >= timeout ):
        return -2
    else:
        return total


GRAND_PIANO = 0
CHURCH_ORGAN = 19
GUITAR=25
DRUMB=115
SAX=65
VIOLA=42
TROMBONE=58
CLAVICORDIO=6
PAD=7

instrument_array=[GRAND_PIANO,CHURCH_ORGAN,GUITAR,DRUMB,SAX,VIOLA,TROMBONE,CLAVICORDIO,PAD]
current_instrument=6

#Init the pygame system
pygame.init()
#Init the pygame midi system
pygame.midi.init()
#Setup the output number 2, this is the timidity interface (check the beginning of the file)
midi_out = pygame.midi.Output(2, 0)

#shift example to the tones (this line have no effect)
octave=3
notes_offset=[x+12*octave for x in notes]

#Here goes the body of the program (
midi_out.set_instrument(instrument_array[current_instrument])
##midi_out.set_instrument(0)

# loop
while True:
    for fr in range(0,5):
        total = 0
        for j in range(0,5):
            total += CapRead(frutas[fr][0],frutas[fr][1]);
        #print total
        #sleep(0.1)
        if ( total > 38 and not frutas[fr][2]):
            midi_out.note_on(notes_offset[fr],127)
            frutas[fr][2] = True
        elif ( total < 38 and frutas[fr][2] ):
            midi_out.note_off(notes_offset[fr],127)
            frutas[fr][2] = False


    
# clean before you leave
GPIO.cleanup()
del midi_out
pygame.midi.quit()
