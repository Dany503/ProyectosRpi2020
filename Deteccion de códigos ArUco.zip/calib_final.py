#Para poder compilar el codigo es necesario anadir las librerias correspondientes a los modulos de ArUco para el tratamiento de imagenes
# y la libreria yaml y path para la gestion y escritura de ficheros.

import cv2
from cv2 import aruco
import yaml
import numpy as np
from pathlib import Path
from tqdm import tqdm

#Mediante esta linea se define la ruta a donde se encuentran los archivos
root = Path(__file__).parent.absolute()

# Flag para calibrar o no la camara
calibrate_camera = True

#Carpeta donde se encuentran las imagenes para el calibrado
calib_imgs_path = root.joinpath("aruco_data")

# Mediante esta linea creamos el diccionario ArUco.
aruco_dict = aruco.getPredefinedDictionary( aruco.DICT_6X6_1000 )

#Es necesario proporcionar las dimensiones de los marcadores para su correcta deteccion
#Asi como la separacion entre ellos

markerLength = 3.75  #Se indica la meidida en cm.

markerSeparation = 0.5

#Creacion de tabla arUco
board = aruco.GridBoard_create(4, 5, markerLength, markerSeparation, aruco_dict)

img = board.draw((864,1080))

#En caso de que el flag este activado se procede a la carga de las imagenes anteriormente capturadas, para que mediante el procesamiento de imagenes
#proporcionado por la libreria ArUco obtener los parametros de calibracion de la camara: Matriz de la camara y Coeficientes de distorsion

arucoParams = aruco.DetectorParameters_create()

if calibrate_camera == True:
    img_list = []
    calib_fnms = calib_imgs_path.glob('*.jpg')
   # print('Using ...', end='')
    for idx, fn in enumerate(calib_fnms):
        #print(idx, '', end='')
        img = cv2.imread( str(root.joinpath(fn) ))
        img_list.append( img )
        h, w, c = img.shape
    print('Calibration images')

    counter, corners_list, id_list = [], [], []
    first = True
    for im in tqdm(img_list):
        img_gray = cv2.cvtColor(im,cv2.COLOR_RGB2GRAY)
        corners, ids, rejectedImgPoints = aruco.detectMarkers(img_gray, aruco_dict, parameters=arucoParams)
        if first == True:
            corners_list = corners
            id_list = ids
            first = False
        else:
            corners_list = np.vstack((corners_list, corners))
            id_list = np.vstack((id_list,ids))
        counter.append(len(ids))
    print('Found {} unique markers'.format(np.unique(ids)))

    counter = np.array(counter)
    print ("Calibrating camera. Please wait...")
    #mat = np.zeros((3,3), float)
    ret, mtx, dist, rvecs, tvecs = aruco.calibrateCameraAruco(corners_list, id_list, counter, board, img_gray.shape, None, None )

    print("Camera matrix is: ")
    print(mtx)
    print(" ")
    print("And is stored in calibration.yaml file along with distortion coefficients : ")
    print(dist)

    data = {'camera_matrix': np.asarray(mtx).tolist(), 'dist_coeff': np.asarray(dist).tolist()}
    with open("calibration.yaml", "w") as f:
        yaml.dump(data, f)
else:
	print("Pass")

cv2.destroyAllWindows()
