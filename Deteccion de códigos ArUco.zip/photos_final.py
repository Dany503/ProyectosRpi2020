import cv2

camera = cv2.VideoCapture(0)
ret, img = camera.read()

#Se toman 20 fotos y se almacenan en el directorio indicado para mas tarde
#utilizarlas en la calibracion de la camara.

path = "/home/ubuntu/aruco_data/"
count = 0
while (count  <  20) :
	name = path + str(count)+".jpg"
	ret, img = camera.read()
	cv2.imshow("Fotos", img)

    	if cv2.waitKey(20) & 0xFF == ord('c'):
        	cv2.imwrite(name, img)
        	cv2.imshow("Fotos", img)
        	count += 1
	
	if cv2.waitKey(10) & 0xFF == ord('q'):
                break;

print("Todas las fotos han sido tomadas.")

cv2.destroyAllWindows()