from easygui import *
import subprocess
import time
import sys
from statem import StateMachine

photos_enable = False
matriz_enable = False
detectar_enable = False
proceso_photos = []
proceso_visor = []
proceso_matriz = []
proceso_detectar = []

def start_window(txt):
    msg = """ ARUCO detection."""

    title = "ARUCO GUI"

    choices = ["Next","Exit"]

    choice = buttonbox(msg, title = title, choices = choices, default_choice= "Next", image = "aruco_portada.png")
    print(choice)
    if choice == "Exit":
        sys.exit(0)
    else:
        return("STATE_Buttons",txt)

def buttons_window(txt):

    msg = "Options"
    reply = buttonbox(msg, choices = ["Exit"], image = ["camera.png","calibration.png","detect.png"], cancel_choice="Exit")

    if reply == "Exit":
        return("STATE_R_U_SURE",txt)
    elif reply == "camera.png":
        return("STATE_Camera",txt)
    elif reply == "calibration.png":
        return("STATE_Calibrar",txt)
    elif reply == "detect.png":
        return("STATE_Detect",txt)

def camera_handler(txt):

    global photos_enable
    global proceso_photos
    global proceso_visor

    if(photos_enable == False):

        photos_enable = True
        time.sleep(3)
        proceso_visor = subprocess.Popen(['python','photos_final.py'])

    else:

        msgbox("Photos already taken.", title="Oops")


    return("STATE_Buttons",txt)

def graficos_handler(txt):

    global proceso_matriz
    global matriz_enable

    if matriz_enable == False:
        matriz_enable = True
        proceso_matriz = subprocess.Popen(['python','calib_final.py'])

    else:
        msgbox("Camera already calibrated.", title="Oops")

    return("STATE_Buttons",txt)


def exit_function(txt):
    global photos_enable
    global proceso_photos
    global proceso_visor
    global proceso_detectar

    time.sleep(3)
    if photos_enable == True:

        proceso_photos.terminate()
        proceso_photos.communicate()

        proceso_visor.terminate()
        proceso_visor.communicate()

    if matriz_enable == True:
        proceso_matriz.terminate()
        proceso_matriz.communicate()

    if detectar_enable == True:
        proceso_detectar.terminate()
        proceso_detectar.communicate()

    return("Bye_state",txt)

def are_you_sure_function(txt):

    msg = "Are you sure?"
    choices = ["Yes","No"]
    reply = buttonbox(msg, choices = choices, cancel_choice="No")

    if reply == "Yes":
        return("STATE_Exit",txt)
    else:
        return("STATE_Buttons",txt)


def cameracontrol_function(txt):
    global detectar_enable
    global proceso_detectar

    if detectar_enable == False:
        detectar_enable = True
        proceso_detectar = subprocess.Popen(['python','detect_final.py'])
    else:
        msgbox("Detection is done.", title="Warning")

    return("STATE_Buttons",txt)


# Funcion MAIN donde se definen los estados de la FSM
if __name__== "__main__":

    m = StateMachine()
    m.add_state("STATE_Welcome", start_window)
    m.add_state("STATE_Buttons", buttons_window)
    m.add_state("STATE_Camera", camera_handler)
    m.add_state("STATE_Calibrar", graficos_handler)
    m.add_state("STATE_Exit", exit_function)
    m.add_state("STATE_R_U_SURE", are_you_sure_function)
    m.add_state("STATE_Detect", cameracontrol_function)
    m.add_state("Bye_state",None,end_state=1)
    m.set_start("STATE_Welcome")
m.run("Exec")
