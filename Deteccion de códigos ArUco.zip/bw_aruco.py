import numpy as np
import cv2
import cv2.aruco as aruco

#Se captura video de manera continua.
cap = cv2.VideoCapture(0)

while(True):

    ret, frame = cap.read()
    print(frame.shape) #480x640

#Se crea el diccionario de codigos.

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    aruco_dict = aruco.Dictionary_get(aruco.DICT_6X6_250)
    parameters =  aruco.DetectorParameters_create()

    print(parameters)

#Se detectan las esquinas de los ArUco en blanco y negro ya que es mas sencillo
#el tratamiento de imagenes.

    corners, ids, rejectedImgPoints = aruco.detectMarkers(gray, aruco_dict, parameters=parameters)
    print(corners)

    gray = aruco.drawDetectedMarkers(gray, corners)

    cv2.imshow('Captura',gray)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()