#La primera parte del código es la misma que la del archivo calib_final, ya
#que el programa se dividió en dos para poder implementar la UI.

import cv2
from cv2 import aruco
import yaml
import numpy as np
from pathlib import Path
from tqdm import tqdm

#Mediante esta linea se define la ruta a donde se encuentran los archivos
root = Path(__file__).parent.absolute()

# Flag para calibrar o no la camara
calibrate_camera = False

#Carpeta donde se encuentran las imagenes para el calibrado
calib_imgs_path = root.joinpath("aruco_data")

# Mediante esta linea creamos el diccionario ArUco.
aruco_dict = aruco.getPredefinedDictionary( aruco.DICT_6X6_1000 )

#Es necesario proporcionar las dimensiones de los marcadores para su correcta deteccion
#Asi como la separacion entre ellos

markerLength = 3.75  #Se indica la meidida en cm.

markerSeparation = 0.5

#Creacion de tabla arUco
board = aruco.GridBoard_create(4, 5, markerLength, markerSeparation, aruco_dict)

img = board.draw((864,1080))

#En este caso, el flag está desactivado y se procede a ejecutar la deteccion en tiempo real
#de los codigos mostrando por pantalla la captura de la camara.

arucoParams = aruco.DetectorParameters_create()

if calibrate_camera == True:
    print("Pass")
else:
    camera = cv2.VideoCapture(0)
    ret, img = camera.read()

    with open('calibration.yaml') as f:
        loadeddict = yaml.safe_load(f)
    mtx = loadeddict.get('camera_matrix')
    dist = loadeddict.get('dist_coeff')
    mtx = np.array(mtx)
    dist = np.array(dist)

    ret, img = camera.read()
    img_gray = cv2.cvtColor(img,cv2.COLOR_RGB2GRAY)
    h,  w = img_gray.shape[:2]
    newcameramtx, roi=cv2.getOptimalNewCameraMatrix(mtx,dist,(w,h),1,(w,h))

    pose_r, pose_t = [], []
    while True:
        ret, img = camera.read()
        img_aruco = img
        im_gray = cv2.cvtColor(img,cv2.COLOR_RGB2GRAY)
        h,  w = im_gray.shape[:2]
        dst = cv2.undistort(im_gray, mtx, dist, None, newcameramtx)
        corners, ids, rejectedImgPoints = aruco.detectMarkers(dst, aruco_dict, parameters=arucoParams)
	img = aruco.drawDetectedMarkers(img, corners, ids, (0,255,0))
        #cv2.imshow("original", img_aruco)
        if len(corners) != 0:
	    pose_r = np.zeros((3, 3))
	    pose_t = np.zeros((1, 3))
	    ret = aruco.estimatePoseSingleMarkers(corners, 0.35, mtx, dist, pose_r, pose_t)
	    rvec, tvec = ret[0][0,0,:], ret[1][0,0,:]

	    print ("Rotation: ")
	    print(rvec)
	    print("Translation: ")
	    print(tvec)
	    print(" ")

            img_aruco = aruco.drawDetectedMarkers(img, corners, ids, (0,255,0))
            img_aruco = aruco.drawAxis(img, newcameramtx, dist, rvec, tvec, 1)
 	    cv2.imshow("Ultimo ArUco detectado.", img_aruco)
	cv2.imshow("Deteccion", img)
        if cv2.waitKey(10) & 0xFF == ord('q'):
                break;


cv2.destroyAllWindows()
