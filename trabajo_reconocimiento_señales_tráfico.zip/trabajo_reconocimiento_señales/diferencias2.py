#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Feb 20 18:19:35 2020

@author: root
"""


import cv2
import numpy as np

from picamera import PiCamera
from time import sleep
from matplotlib import pyplot as plt

camera = PiCamera()
camera.resolution = (640,480)
camera.rotation = 180
camera.start_preview(fullscreen=False, window=(30,30,320,240))
for i in range(0,5):
    print 5-i
    sleep(1)
camera.capture('/home/pi/git/practicas_sdaa/imagen1.jpg')
camera.stop_preview()
camera.close()


#
im=cv2.imread('imagen1.jpg')
#im=cv2.imread('dcha.png')

gris=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
cv2.imwrite('gris.png',gris)
desen=cv2.GaussianBlur(gris,(7,7),cv2.BORDER_DEFAULT)
cv2.imwrite('desen.png',desen)
ret,th1=cv2.threshold(desen,127,255,cv2.THRESH_BINARY)
cv2.imwrite('bina.png',th1)

contornos,hierarchy=cv2.findContours(th1,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)


for cnt in contornos :
    if cv2.contourArea(cnt) > 50000:
        approx=cv2.approxPolyDP(cnt,0.07*cv2.arcLength(cnt,True),True)
        cv2.drawContours(im,[approx],0,(0,0,255),4)
        x=approx.ravel()[0]
        y=approx.ravel()[1]
        z=approx[0][0]
        x_min=z[0]
        y_min=z[1]
        x_max=z[0]
        y_max=z[1]
        
        if len(approx)==4:
            print(approx)
            
            for i in [0,1,2,3]:
               
                d=approx[i][0]
                

                if (d[0]>x_max):
                    x_max=d[0]
                
                if (d[0]<x_min):
                    x_min=d[0]
                    
                if d[1]>y_max:
                    y_max=d[1]
                    
                if d[1]<y_min:
                    y_min=d[1]
 
            cv2.putText(im,"Rectangulo",(x,y),cv2.FONT_HERSHEY_COMPLEX,1,(0,0,255))
    
w=x_max-x_min
h=y_max-y_min
#crop=im[y_min:y_min+h,x_min:x_min+w] 
#dsize=(500,500)
#out=cv2.resize(crop,dsize)
#cv2.imwrite('crop.png',out)
   
cv2.imshow('original',im)
#cv2.imshow('crop',crop)
cv2.imshow('binary',th1)

imagen1=cv2.imread('crop.png')
imagen2=cv2.imread('30PRUEBA.jpeg')
gris1=cv2.cvtColor(imagen1,cv2.COLOR_BGR2GRAY)
cv2.imwrite('cropgris.png',gris1)
gris2=cv2.cvtColor(imagen2,cv2.COLOR_BGR2GRAY)
cv2.imwrite('plantillagris.png',gris2)
ret,th1=cv2.threshold(gris1,127,255,cv2.THRESH_BINARY)
cv2.imwrite('cropbi.png',th1)
ret,th2=cv2.threshold(gris2,127,255,cv2.THRESH_BINARY)
cv2.imwrite('birpla.png',th2)

XOR=cv2.bitwise_xor(th1,th2)
cv2.imwrite('XOR.png',XOR)

print(XOR)
x=cv2.countNonZero(XOR)
print(x)
porcentaje=(x/250000.0)*100
print(porcentaje)
if porcentaje<15:
    y=100-porcentaje
    print('La señal corresponde con una señal de límitación de velocidad a 30km/h')
    print('el porcentaje de coincidencia es de:',y)
    cv2.imshow('XOR',XOR)
else:
    imagen2=cv2.imread('90PRUEBA.png')
    gris2=cv2.cvtColor(imagen2,cv2.COLOR_BGR2GRAY)
    ret,th3=cv2.threshold(gris2,127,255,cv2.THRESH_BINARY)
    XOR=cv2.bitwise_xor(th1,th3)
   
    print(XOR)
    x=cv2.countNonZero(XOR)
    print(x)
    porcentaje=(x/250000.0)*100
    if porcentaje<15:
        print('La señal corresponde con una señal de límitación de velocidad a 90km/h')
        cv2.imshow('XOR',XOR)
        y=100-porcentaje
        print('el porcentaje de coincidencia es de:',y)
    else:
        imagen2=cv2.imread('prohibidoPRUEBA.png')
        gris2=cv2.cvtColor(imagen2,cv2.COLOR_BGR2GRAY)
        ret,th4=cv2.threshold(gris2,127,255,cv2.THRESH_BINARY)
        XOR=cv2.bitwise_xor(th1,th4)
        
        print(XOR)
        x=cv2.countNonZero(XOR)
        print(x)
        porcentaje=(x/250000.0)*100
        if porcentaje<15:
            print('La señal corresponde con una señal de prohibido')
            cv2.imshow('XOR',XOR)
            y=100-porcentaje
            print('el porcentaje de coincidencia es de:',y)
        else:
            imagen2=cv2.imread('drchaPRUEBA.jpeg')
            gris2=cv2.cvtColor(imagen2,cv2.COLOR_BGR2GRAY)
            ret,th5=cv2.threshold(gris2,127,255,cv2.THRESH_BINARY)
            XOR=cv2.bitwise_xor(th1,th5)
            
            print(XOR)
            x=cv2.countNonZero(XOR)
            print(x)
            porcentaje=(x/250000.0)*100
            if porcentaje<15:
                print('La señal corresponde con una señal que informa que solo puede ir a la derecha')
                cv2.imshow('XOR',XOR)
                y=100-porcentaje
                print('el porcentaje de coincidencia es de:',y)
            else:
                imagen2=cv2.imread('izqdaPRUEBA.jpeg')
                gris2=cv2.cvtColor(imagen2,cv2.COLOR_BGR2GRAY)
                ret,th6=cv2.threshold(gris2,127,255,cv2.THRESH_BINARY)
                XOR=cv2.bitwise_xor(th1,th6)
                
                print(XOR)
                x=cv2.countNonZero(XOR)
                print(x)
                porcentaje=(x/250000.0)*100
                if porcentaje<15:
                    print('La señal corresponde con una señal que informa que solo puede ir a la izquiercha')
                    cv2.imshow('XOR',XOR)
                    y=100-porcentaje
                    print('el porcentaje de coincidencia es de:',y)
                else:
                    imagen2=cv2.imread('rectoPRUEBA.png')
                    gris2=cv2.cvtColor(imagen2,cv2.COLOR_BGR2GRAY)
                    ret,th7=cv2.threshold(gris2,127,255,cv2.THRESH_BINARY)
                    XOR=cv2.bitwise_xor(th1,th7)
                    
                    print(XOR)
                    x=cv2.countNonZero(XOR)
                    print(x)
                    porcentaje=(x/250000.0)*100
                    if porcentaje<15:
                        print('La señal corresponde con una señal que informa que solo puede ir a la recto')
                        cv2.imshow('XOR',XOR)
                        y=100-porcentaje
                        print('el porcentaje de coincidencia es de:',y)
                    else:
                        print('NO SE ENCUENTRA COINCIDENCIA')

cv2.waitKey(0)
cv2.destroyAllWindows()