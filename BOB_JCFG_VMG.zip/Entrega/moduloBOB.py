# -*- coding: utf-8 -*-
"""
Módulo principal (sin multiprocessing)

1.- Asegurarse que el SenseHat está correctamente configurado y su librería
está instalada.

2.- Medir aceleraciones del SenseHat para establecer un umbral_accel correcto.
Debe ser tal que cuando lo zarandee sobrepase ese valor y estando sobre la mesa no

3.- Para el submódulo Bluetooh es necesario instalar "pybluez" con pip

4.- Comprobar datos Whatsapp_JC y Whatsapp_Victor
AYUDA IMPORTANTE: USAR SESSION BOSS EN FIREFOX Y RESTAURAR ARCHIVO SESSION BOSS ADJUNTO
AYUDA JSON:https://www.w3schools.com/python/python_json.asp
@author: JC
"""
from sense_hat import SenseHat #Diccionario : https://pythonhosted.org/sense-hat/api/
from bluetool import Bluetooth #De pybluez. Diccionario: https://pybluez.readthedocs.io/en/latest/api/discover_devices.html
from twilio.rest import Client #Whatsapp Message
import time
import json
"""Inicialización de variables"""
#Diccionario Escalable donde añadir todos los dispositivos "de confianza" para Bob
Bluetooh_devices={'JC':'Galaxy J7','Victor':'Mi A3'} 

#Diccionario Escalable que nos dice la gente que hay en casa
Presencia={'JC': False ,'Victor': False,'Guests': 0,'Hosts': 0}
Presencia_anterior={'JC': False ,'Victor': False,'Guests': 0,'Hosts': 0}
#Diccionario que almacena los datos whatsapp del admin de Bob que recibirá notificaciones.
#Se debe añadir uno por perfil de usuario que se comunicará via whatsapp con Bob
Whatsapp_JC={ 'account_sid' : 'ACd17f5aad6f3f6e3c75e5d800860fe2bf','auth_token':'cfee71c1193d3bc25f4584877c963ac2','number':'whatsapp:+34633461255'}
Whatsapp_Victor={ 'account_sid' : 'ACXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX','auth_token':'your_auth_token','number':'whatsapp:+34601006395'}
Whatsapp_Bob='whatsapp:+14155238886'
"""Whatsapp_Victor={ 'account_sid' : 'ACb6a7dc1b7fe742f43657806914427d3c','auth_token':'25239a01b6582a215ee7ae0156cc0be9','number':'whatsapp:+34601006395'}
Whatsapp_JC={ 'account_sid' : 'ACXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX','auth_token':'your_auth_token','number':'whatsapp:+34633461255'}"""

f = open('flag.txt','w')
f.write('0')
f.close()
#Información para SUBMÓDULO DE ALARMA
tiempo_desactivacion=15 #Tiempo que hay para meter el PIN a la llegada
alarm_status= False
lock_pin=['up','up'] #PIN De seguridad configurable

JC={'Bluetooh':'Galaxy J7','Temperatura':27}
Victor={'Bluetooh':'Mi A3','Temperatura':30}
Consigna={'Victor':27 ,'JC':30}
Temperaturas={'Comun':20,'Victor':20,'JC':20,'Actual':0,'Humedad':0} #Dependencias Comunes, de un host y de otro host
Actuaciones={'Comun':'Apagado','Victor':'Apagado','JC':'Apagado'} #Estado del sistema en las dependencias
       
"""Variables aux"""
bluetooth = Bluetooth()
bluetooth.scan()
    
sense = SenseHat()
sense.set_imu_config(False, False, True)  # Activar acelerómetro
umbral_accel=0.09
R = [255, 0, 0] #Red
B = [0, 0, 255]
G = [0, 255, 0]
A = [0, 255, 255]
O=R
question_mark = [
O, O, O, O, O, O, O, O,
O, O, O, O, O, O, O, O,
O, O, O, O, O, O, O, O,
O, O, O, O, O, O, O, O,
O, O, O, O, O, O, O, O,
O, O, O, O, O, O, O, O,
O, O, O, O, O, O, O, O,
O, O, O, O, O, O, O, O
]

sense.set_pixels(question_mark)

"""FUNCIONES AUXILIARES"""
def aviso_presencia(persona,invitados,tipo,Whatsapp,Bob):
    
    account_sid=Whatsapp['account_sid']
    auth_token=Whatsapp['auth_token']
    
    client = Client(account_sid, auth_token)
    if tipo==0 :
        mensaje= 'Hey, al habla Bob! '+ persona + ' acaba de llegar y ya de paso decirte que hay ' + str(invitados) + ' invitados en casa. Un saludo! :)' 
    if tipo==1: 
        mensaje= 'Hey, al habla Bob! ' + persona + ' acaba de salir. Un saludo! :)' 
    """if tipo==2:
        mensaje= '¡Atención!, alguien está intentando entrar como' + persona + ' avisaré al servicio de seguridad!'"""
    if tipo==3:
        mensaje= '!Atención!, alguien está manipulando mi sistema!!'
        
    message = client.messages.create(
                              body=mensaje,
                              from_= Bob, 
                              to=Whatsapp['number']
                          )
    print(message.sid)
     
"""def alarma(persona):
    global alarm_status
    G = [0, 255, 0]  # Green
    R = [255, 0, 0] #Red
    B=  [0, 0 , 0 ]
    W = [255, 255, 255]  # White
    intentos=3 #Intentos para introducir Pin
    sense.show_message('Pin attemps: ' + str(intentos), text_colour=[255, 255, 255])
    indice_pin=0
      
    while intentos > 0: #tiempo_desactivacion es una var global 
        
        for event in sense.stick.get_events(): #COMPROBAR SI FUNCIONA. ¿DEVUELVE SOLO LOS PULSADOS DESDE EL ULTIMO GET EVENT?
            print event
            if event.action == 'pressed': #Si he presionado
                if event.direction==lock_pin[indice_pin]: #En la direccion coincidente con el pin
                    indice_pin=indice_pin + 1
                    if indice_pin==2:
                        break #Dejo el for por acertar
                else: 
                    indice_pin=0 #Reinicio por que me he equivocado
                    print 'errorneo'
        
            if indice_pin==2:
                break #dejo el while
                
        if indice_pin!=2:
            indice_pin=0
            intentos=intentos - 1
            
        time.sleep(3) #Espera de 10 segundos para meter combinacion
            
    print 'hola0'                    
    if indice_pin==2:
        sense.show_message('Hey!' + persona +'Welcome Back! :)', text_colour=[0, 255, 0])
        time.sleep(10)
        O=G #MATRIZ A VERDE
        question_mark = [
        O, O, O, O, O, O, O, O,
        O, O, O, O, O, O, O, O,
        O, O, O, O, O, O, O, O,
        O, O, O, O, O, O, O, O,
        O, O, O, O, O, O, O, O,
        O, O, O, O, O, O, O, O,
        O, O, O, O, O, O, O, O,
        O, O, O, O, O, O, O, O
        ]
        
        sense.set_pixels(question_mark)
        alarm_status= False #Se reactiva cuando la casa se queda vacia
        #Si aciertas te da la bienvenida
        
    if intentos==0:        
        sense.show_message('ERROR, CALLING HOSTS!', text_colour=[0, 255, 0])
        time.sleep(10)
        O=R #MATRIZ A ROJO
        question_mark = [
        O, O, O, O, O, O, O, O,
        O, O, O, O, O, O, O, O,
        O, O, O, O, O, O, O, O,
        O, O, O, O, O, O, O, O,
        O, O, O, O, O, O, O, O,
        O, O, O, O, O, O, O, O,
        O, O, O, O, O, O, O, O,
        O, O, O, O, O, O, O, O
        ]
        
        sense.set_pixels(question_mark)
        aviso_presencia(persona,0,2,Whatsapp_JC,Whatsapp_Bob) #2 aviso alarma
       #Si fallas 5 veces no se  bloquea pero avisará a seguridad y a los host                
                    
    time.sleep(10) #Tiempo para leer el mensaje           
        
       
    """



while True: #Bucle Principal de controlgyroscope only
    #SUBMÓDULO TEMPERATURA. ADQUISICIÓN DE DATOS
    global alarm_status
    bluetooth.scan()
    print Actuaciones
    for personas in Presencia:
       Presencia_anterior[personas]=Presencia[personas]
    #Actualizacion de diccionarios
    f = open('flag.txt','r')
    flag = f.read()
    f.close()
    
    if flag == '1':
        print 'si entra'
        with open('Consigna2.txt') as json_file:
            Consigna2 = json.load(json_file)
       
        with open('Actuaciones2.txt') as json_file:
            Actuaciones2 = json.load(json_file)
    
        with open('Temperaturas2.txt') as json_file:
            Temperaturas2 = json.load(json_file)
        
        for personas in Consigna2:
           Consigna[personas]=Consigna2[personas]
        for personas in Actuaciones2:
           Actuaciones[personas]=Actuaciones2[personas]
        
        for personas in Temperaturas2:
           Temperaturas[personas]=Temperaturas2[personas]
        f = open('flag.txt','w')
        f.write('0')
        f.close()
    
    #Adquisicion de datos
    Humedad=sense.get_humidity()
    Humedad = round(Humedad,2)
    print Humedad
    Temperatura=sense.get_temperature()
    raw = sense.get_accelerometer_raw() #Raw es un diccionario en python. 
    #Ayuda diccionarios https://developer.rhino3d.com/guides/rhinopython/python-dictionaries/
    accel_x = raw['x'] #Volcado a variables normales, del diccionario
    accel_y=  raw['y']
    accel_z=  raw['z']
    print Humedad
    print Temperatura
    print accel_x
    print accel_y
    print accel_z
    Temperaturas['Actual']= Temperatura
    Temperaturas['Humedad']= Humedad
    #Detección de movimiento (Simulación de hackeo por movimientos)
    if accel_x > umbral_accel or accel_y > umbral_accel:
        Alarma_accel=True
        aviso_presencia('-',Presencia['Guests'],3,Whatsapp_JC,Whatsapp_Bob) #3 hacking
    else:
        Alarma_accel=False
    
    #SUBMOÓDULO BLUETOOH. ESCANEO  
    #IMPORTANTE. Reinicio Presencia (A ESCALAR CON MAS HOSTS)
    
    #Guardamos el estado de presencia del escaneo pasado para detectar llegadas
    
    Presencia['Guests']= 0
    Presencia['Hosts']= 0
    Presencia['JC']=False
    Presencia['Victor']=False
    
    
    devices=bluetooth.get_available_devices()
    print devices
    for i in devices:
        bluetooth.remove(i.get('mac_address'))
 
    scan_names=[0]
    n=0
    
    for i in devices:
        scan_names.insert(n,i.get('name'))

        n=n + 1
    
    scan_names.remove(0)    

    for target_name in scan_names: #Recorro la lista de nombres encontrados
        flag_guest=1 #Supongo que el nombre encontrado es de un invitado 
        for persona,device_name in Bluetooh_devices.items(): 
            #Comprueba si ese nombre está en la lista de disp de confianza de Bob
            if target_name==device_name:
                Presencia[persona]=True #La persona está en casa
                Presencia['Hosts']=Presencia['Hosts'] + 1
                flag_guest=0 #Si es un Host, ya no es Guest
               
        if flag_guest==1:
            Presencia['Guests']=Presencia['Guests'] + 1
        else:
            flag_guest==1 #Para la siguiente iteración
    llegadas=0
    print Presencia_anterior
    print Presencia
    for persona,device_name in Bluetooh_devices.items():
        
        print '...........................'
        if Presencia[persona]== True and Presencia_anterior[persona]==False:
            #Persona ha llegado a casa
            aviso_presencia(persona,Presencia['Guests'],0,Whatsapp_JC,Whatsapp_Bob) #0 cuando es llegada
               #alarma(persona) #Si esta activada entonces pido pin para desactivarla
               
            if Actuaciones[persona]=='Apagado': #puede estar encendido por Whatsapp
                print Consigna[persona]
                Temperaturas[persona]=Consigna[persona] #Si no estaba encendido lo pongo.
                Actuaciones[persona]='Encendido'
                print Actuaciones[persona]
                if Actuaciones['Comun']=='Encendido': 
                #Aportar a la zona comun. Si su dependencia ya estaba encendida ya habrá aportado a la zona comun, por eso se mete en este if
                    Temp_media=0
                    n_media=0
                    for activo in Actuaciones:
                        if Actuaciones[activo]=='Encendido' and activo!='Comun': 
                        #Busco los  sistemas encendidos  para rehacer la media en la zona comun
                            Temp_media=Temp_media+Temperaturas[activo]
                            n_media=n_media + 1
                    
                    Temperaturas['Comun']=Temp_media/n_media
                    Actuaciones['Comun']='Encendido' #Para asegurar
                else:
                    print Consigna[persona]
                    Temperaturas['Comun']=Consigna[persona]    
                    Actuaciones['Comun']='Encendido'
                    
                
        if Presencia[persona]==False and Presencia_anterior[persona]==True:
            #Persona ha dejado casa
        
            aviso_presencia(persona,Presencia['Guests'],1,Whatsapp_JC,Whatsapp_Bob) #1 cuando es salida
            Actuaciones[persona]='Apagado'
            print Actuaciones[persona]
            print 'pepe'
            if Actuaciones['Comun']=='Encendido':
                Temp_media=0
                n_media=0
                for activo in Actuaciones: #Con esto no esta contada la posibilidad de que solo se encienda la zona comun pero bueno
                    if Actuaciones[activo]=='Encendido' and activo!='Comun': 
                    #Busco los  sistemas encendidos  para rehacer la media en la zona comun
                        Temp_media=Temp_media+Temperaturas[activo]
                        n_media=n_media + 1
                if Temp_media!=0:        
                    Temperaturas['Comun']=Temp_media/n_media
                    Actuaciones['Comun']='Encendido' #Para asegurar
                else:
                    Actuaciones['Comun']='Apagado'
            
        if Presencia['Hosts'] == 0 :
            alarm_status=True
            O=R
            question_mark = [
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O
            ]
        elif Presencia['JC'] == True and Presencia['Victor'] == False:
            O=B
            question_mark = [
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O
            ]
        elif Presencia['JC'] == False and Presencia['Victor'] == True:
            O=G
            question_mark = [
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O
            ]
        elif Presencia['JC'] == True and Presencia['Victor'] == True:
            O=A
            question_mark = [
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O,
            O, O, O, O, O, O, O, O
            ]
            
            
        sense.set_pixels(question_mark)
        
        with open('Presencia.txt', 'w') as outfile:
            json.dump(Presencia, outfile)
        with open('Consigna.txt', 'w') as outfile:
            json.dump(Consigna, outfile)
        with open('Temperaturas.txt', 'w') as outfile:
            json.dump(Temperaturas, outfile)
        with open('Actuaciones.txt', 'w') as outfile:
            json.dump(Actuaciones, outfile)
        time.sleep(4)
        
            
            
            
        
                
            
            
                
                
                
   

        

        
        
            
    
    
    
      
        