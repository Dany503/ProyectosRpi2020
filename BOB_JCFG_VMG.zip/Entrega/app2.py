#!/home/pi/pywhatsapp
# ? coding: latin-1 -*-
import os, sys
import json
from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse

app2 = Flask(__name__)

Personas = {'JC':'whatsapp:+34633461255', 'Victor':'whatsapp:+34601006395'}
    
@app2.route('/', methods=['GET','POST'])
def bot():
    incoming_msg = request.values.get('Body', '').lower()
    origen = request.values.get('From', '').lower()
    resp = MessagingResponse()
    msg = resp.message()
    responded = False
    for i in Personas:
        if Personas[i]== origen:
            nombre=i
            
   
    
    with open('Presencia.txt') as json_file:
        Presencia = json.load(json_file)
        
    
    with open('Temperaturas.txt') as json_file:
        Temperaturas = json.load(json_file)
    
    with open('Consigna.txt') as json_file:
        Consigna = json.load(json_file)
    
    with open('Actuaciones.txt') as json_file:
        Actuaciones = json.load(json_file)
    
    with open('Temperaturas2.txt', 'w') as outfile:
        json.dump(Temperaturas, outfile)
    with open('Consigna2.txt', 'w') as outfile:
        json.dump(Consigna, outfile)
    with open('Actuaciones2.txt', 'w') as outfile:
        json.dump(Actuaciones, outfile)
   
    
    if 'casa' in incoming_msg:
        mensaje= 'Hola' + ' ' + nombre + ', ' + 'actualmente en casa '
        mensaje2 = '.'
        n = 0
        for persona in Presencia:
            if Presencia[persona]==True and persona!='Hosts' and persona!='Guests' :
                
                
                if n==0:
                    mensaje = mensaje + 'esta ' + persona
                else:
                    mensaje = mensaje + ' y ' + persona
                
                n = n + 1
            if persona == 'Guests' and Presencia['Hosts']>0:
                if Presencia[persona]==1 :
                    mensaje2 = '. Tambien hay ' + str(Presencia[persona]) + ' invitado.' 
                elif Presencia[persona]>1:
                    mensaje2 = '. Tambien hay ' + str(Presencia[persona]) + ' invitados.'
                    
        if n==0:
            mensaje = mensaje + 'no hay nadie ;)'
                     
        msg.body(str(mensaje + mensaje2))
        responded=True
    if 'acondicion' in incoming_msg:
    
        aux = ''    
            
        
        if 'programa' in incoming_msg:
            Temperaturas[nombre] = Consigna[nombre]
            Actuaciones[nombre]='Encendido'
            Temp_media=0
            n_media=0
            for activo in Actuaciones:
                    print Temp_media
                    if Actuaciones[activo]=='Encendido' and activo!='Comun': 
                    #Busco los  sistemas encendidos  para rehacer la media en la zona comun
                        Temp_media=Temp_media+Temperaturas[activo]
                        n_media=n_media + 1
                
                        Temperaturas['Comun']=Temp_media/n_media
                        Actuaciones['Comun']='Encendido'
                        print Actuaciones
            
                    else:
                        Temperaturas['Comun']=Temperaturas[nombre]     
                        Actuaciones['Comun']='Encendido'
            f = open('flag.txt','w')
            f.write('1')
            f.close()        
            with open('Temperaturas2.txt', 'w') as outfile:
                json.dump(Temperaturas, outfile)
            with open('Actuaciones2.txt', 'w') as outfile:
                json.dump(Actuaciones, outfile)
            msg.body('Hecho!! Las zonas comunes de la casa se han establecido a ' + str(Temperaturas['Comun']) + ' grados.'  )
            responded=True
        else:
            for k in incoming_msg:
                
                if k.isdigit():
                    aux = aux + k
            
                
                
        if aux != '':
            aux = int(aux)
            Temperaturas[nombre]=aux #Si no estaba encendido lo pongo.
            Actuaciones[nombre]='Encendido'
            print Actuaciones
                
            if Actuaciones['Comun']=='Encendido': 
            
                Temp_media=0
                n_media=0
                for activo in Actuaciones:
                    print Temp_media
                    if Actuaciones[activo]=='Encendido' and activo!='Comun': 
                    #Busco los  sistemas encendidos  para rehacer la media en la zona comun
                        Temp_media=Temp_media+Temperaturas[activo]
                        n_media=n_media + 1
                
                        Temperaturas['Comun']=Temp_media/n_media
                        Actuaciones['Comun']='Encendido'
                        print Actuaciones
            else:
                Temperaturas['Comun']=aux     
                Actuaciones['Comun']='Encendido'
                print Actuaciones
            f = open('flag.txt','w')
            f.write('1')
            f.close()        
            with open('Temperaturas2.txt', 'w') as outfile:
                json.dump(Temperaturas, outfile)
            with open('Actuaciones2.txt', 'w') as outfile:
                json.dump(Actuaciones, outfile)
            msg.body('Hecho!! Las zonas comunes de la casa se han establecido a ' + str(Temperaturas['Comun']) + ' grados.'  )
            responded=True
    if 'apaga' in incoming_msg:
        mensajeA = ''
        mensajeB= ''
        for activo in Actuaciones:
            if activo == nombre:
                if Actuaciones[activo]=='Encendido':
                    Actuaciones[activo]='Apagado'
                    mensajeA= 'Ahora mismo. '
                else: 
                    mensajeA='Tu habitacion ya tiene el sistema apagado. '
            elif activo == 'Comun' and Actuaciones[activo]=='Encendido':
                bandera = 0
                print bandera 
                for presente in Presencia:
                    if presente != nombre and presente != 'Guests' and presente!= 'Hosts'and Presencia[presente]== True :
                        bandera = 1
                if bandera == 1:
                    mensajeB = mensajeB + 'El sistema de las zonas comunes esta siendo utilizado por otro, asi que no lo podre apagar.'
                    
                else:
                    mensajeB = mensajeB + 'Tambien apague la zona comun'
                    print 'pepe'
                    Actuaciones[activo] = 'Apagado'
            elif activo == 'Comun' and Actuaciones[activo] == 'Apagado':
                mensajeB = mensajeB + 'El sistema de las zona comun esta apagado'
        f = open('flag.txt','w')
        f.write('1')
        f.close()       
        with open('Temperaturas2.txt', 'w') as outfile:
                json.dump(Temperaturas, outfile)
        with open('Actuaciones2.txt', 'w') as outfile:
            json.dump(Actuaciones, outfile)
        msg.body(mensajeA + mensajeB)
        responded = True
                        
    if 'clima' in incoming_msg:
        
        mensajeT = nombre + ', la temperatura de tus dependencias es de ' + str(Temperaturas[nombre]) + ' grados ' + 'y la de la zona comun es ' + str(Temperaturas['Comun']) + ' grados' + ', la humedad es de ' + str(Temperaturas['Humedad']) + ' sobre 100.' 
        msg.body(str(mensajeT))
        responded=True
    if 'sistema' in incoming_msg:
        mensajeS = 'El sistema acondicionador esta: '
        for activo in Actuaciones:
            mensajeS = mensajeS + ' ' + Actuaciones[activo] + ' en '  
            if activo == 'Comun':
                mensajeS = mensajeS + 'las zonas comunes con temperatura asignada de ' + str(Temperaturas[activo]) + ' grados.'
            else:
                mensajeS = mensajeS + ' la habitacion de ' + activo + ' con temperatura asignada de ' + str(Temperaturas[activo]) + ' grados.'
        #f = open('flag.txt','w')
        #f.write('1')
        #f.close()        
        #with open('Temperaturas2.txt', 'w') as outfile:
        #    json.dump(Temperaturas, outfile)
        msg.body(str(mensajeS))
        responded=True
    if 'consigna' in incoming_msg:
        if 'cambia' in incoming_msg:
            aux = ''    
            
            for k in incoming_msg:
                
                if k.isdigit():
                    aux = aux + k
            
            if aux != '':
                aux = int(aux)
                print Consigna
                Consigna[nombre] = aux
                print Consigna
                
                f = open('flag.txt','w')
                f.write('1')
                f.close()
                with open('Consigna2.txt', 'w') as outfile:
                    json.dump(Consigna, outfile)
                msg.body('Por supuesto!')
                responded = True
        if 'recuerda' in incoming_msg:
            msg.body(str(Consigna[nombre]))
        
            responded=True
    if 'reset' in incoming_msg:
        Consigna={'Victor':27,'JC':30}
        Temperaturas={'Comun':20,'Victor':20,'JC':20,'Actual':0,'Humedad':0} #Dependencias Comunes, de un host y de otro host
        Actuaciones={'Comun':'Apagado','Victor':'Apagado','JC':'Apagado'}
        with open('Temperaturas2.txt', 'w') as outfile:
            json.dump(Temperaturas, outfile)
        with open('Actuaciones2.txt', 'w') as outfile:
            json.dump(Actuaciones, outfile)
        with open('Consigna2.txt', 'w') as outfile:
            json.dump(Consigna, outfile)
        msg.body('Reboot Completed ' + nombre)
        responded = True
    
    if 'gracias' in incoming_msg:
        msg.body("De nada " + nombre + ', escribeme si necesitas algo!')
        responded = True
    if 'invitado' in incoming_msg:
       
        if Presencia[nombre]== True:
    
            mensajeI = nombre + ', estan todos contigo, sabes perfectamente cuantos hay!'

        else:
            for persona2 in Presencia:
                if Presencia[persona2]==True:
                    mensajeI = nombre + ', llama a ' + persona2 + ' que esta en casa con ellos'
        msg.body(mensajeI)
        responded = True
    if 'presenta' in incoming_msg:
        msg.body('Hola ' + nombre + ' estabais tardando ya!! Cuando quieras me presento!!')
        responded = True
        
    if 'hola' in incoming_msg:
        msg.body('Hola ' + nombre + ', a tu disposicion para lo que quieras!' )
        responded = True
    
    if 'genial' in incoming_msg:
        msg.body('Perfecto,' + nombre +'!! Buenas a todos! Soy Bob, la centralita de Juan Carlos ' +
                 'y Victor y mis funciones son detectar la presencia, medir la temperatura/humedad, ' +
                 'tengo a si mismo un sensor que se activa cuando alguien me manipula. Aparte de esto '+ 
                 'soy capaz de modificar la temperatura de las habitaciones de JC y Victor y sus zonas comunes.'+
                 ' La presencia la obtengo via Bluetooth y toda la comunicacion se hace atraves de Whatsapp.')
        responded=True
    if 'esto' in incoming_msg:
        msg.body('Aqui entramos en un aspecto mas tecnico, os paso esta presentacion y ya vosotros les contais el resto!! https://drive.google.com/file/d/15GuI-KICQeaSJ9xYo98Cu-8YxFKEFOt_/view?usp=sharing')
        responded=True
     
        
    if not responded:
        msg.body('Lo siento, no soy tan listo como Siri aun, de momento preguntaselo a ella')
        
    
            
    return str(resp)

if __name__ == "__main__":
    app2.run(debug=True)



