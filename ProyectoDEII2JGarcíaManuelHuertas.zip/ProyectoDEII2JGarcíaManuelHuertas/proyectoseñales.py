# -*- coding: utf-8 -*-
import sys
sys.path.append('/usr/local/lib/python2.7/dist-packages')
import os
import cv2 
import numpy as np
from PIL import Image
import pytesseract
import imutils
import wikipedia
import telebot
import shutil
from os import walk




##Definimos el camino de la carpeta donde archivaremos en nuestra Raspberry las imágenes 
path='directorio_raspberry'

##Si existe el camino deseado en el puerto USB, reescribimos el "path" marcado anteriormente 
if os.path.exists('directorio_usb'):
    if os.path.exists(path):
        shutil.rmtree(path)
    shutil.copytree('directorio_usb', path)


##Creamos una lista ordenada por fecha de modificación en el directorio de nuestra raspberry
##en el que almacenamos las imagenes
##la imagen de más tardía modificación será la usada
ficherosdirectorio = os.listdir(path)
listaficheros = [os.path.join(path,i) for i in ficherosdirectorio]
lista_tiempo = sorted(listaficheros, key=os.path.getmtime)




##########Procesamiento imagen#############
a=lista_tiempo[0]
img =cv2.imread(a)
cropped = img


#== Parámetros           
BLUR = 21
CANNY_THRESH_1 = 10
CANNY_THRESH_2 = 1000
MASK_DILATE_ITER = 10
MASK_ERODE_ITER = 10
MASK_COLOR = (1.0,1.0,1.0) # In BGR format


#img = cropped

gray = cv2.cvtColor(cropped,cv2.COLOR_BGR2GRAY) ## se pasa la imagen a grises

##búsqueda de bordes con límites elegidos, dilatación y erosión
edges = cv2.Canny(gray, CANNY_THRESH_1, CANNY_THRESH_2)
edges = cv2.dilate(edges, None)
edges = cv2.erode(edges, None)

#búsqueda contornos selección de áreas y relleno
contour_info = []
contours= cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)[0]
for c in contours:
    contour_info.append((
        c,
        cv2.isContourConvex(c),
        cv2.contourArea(c),
    ))
contour_info = sorted(contour_info, key=lambda c: c[2], reverse=True)
max_contour = contour_info[0]
##creamos máscara de los contornos
mask = np.zeros(edges.shape)
for c in contour_info:
    cv2.fillConvexPoly(mask, c[0], (255))


mask = cv2.dilate(mask, None, iterations=MASK_DILATE_ITER)
mask = cv2.erode(mask, None, iterations=MASK_ERODE_ITER)
mask = cv2.GaussianBlur(mask, (BLUR, BLUR), 0) ##filtro eliminación de ruido
mask_stack = np.dstack([mask]*3)   


mask_stack  = mask_stack.astype('float32') / 255.0         
img         = img.astype('float32') / 255.0    
masked = (mask_stack * img) + ((1-mask_stack) * MASK_COLOR)  
masked = (masked * 255).astype('uint8')   
#color select

#hsv = cv2.cvtColor(masked, cv2.COLOR_BGR2HSV)
    
#lower_black = np.array([0,0,0])
#upper_black = np.array([80,255,255])
    
#mas = cv2.inRange(hsv, lower_red, upper_red)
#res = cv2.bitwise_and(masked,masked, mask= mas)

             

 
#cv2.imshow('img1', masked)  
                               

img1 = masked 
img1 = cv2.resize(img1, (620,480) ) 

gray = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY) 
gray = cv2.bilateralFilter(gray, 11, 17, 17) ##filtro bilateral para remarcar bordes
#############Fin procesamiento imagen##########




##Uso de la librería tessercat para convertir nuestra imagen filtrada en caracteres tipo "unicode"
original = pytesseract.image_to_string(gray)


##Conversión de tipo unicode a string para facilitar más tarde la búsqueda
##Código no válido para caracteres no ascii
string=original.lower().encode('ascii', 'ignore')
##Comando para usar la wikipedia a través de su librería en español
wikipedia.set_lang("es");

##Añadimos a la palabra de caracteres obtenida a través de la librería tessercat
##el estring " españa" para facilitar la búsqueda en wikipedia
busqueda=string+ " españa"


##Cogemos del resumen de la página de wikipedia las 2 primeras frases que serán envíadas
##Por telegram. Hemos decidido que más frases en algunos casos podría ser demasiado, pero configurable
resumen=wikipedia.summary (busqueda, sentences=2);


##print(wikipedia.page("Sevilla").images)

##Nos conectamos a nuestro bot de Telegram
TOKEN = "token_movil"
tb = telebot.TeleBot(TOKEN)	#create a new Telegram Bot object


##Mensaje de bienvenida, capitalize para cambiar el primer caracter a mayúscula
bienvenida="Ha entrado en " + string.capitalize()



tb.send_message('id_bot', bienvenida)

#Manda resumen wikipedia
tb.send_message('id_bot', resumen)

tb.send_message('id_bot', "Aquí algunas imágenes de " + string.capitalize())


#Manda algunas imágenes
#Imágenes aleatorias wikipedia
tb.send_message('id_bot', wikipedia.page(busqueda).images[0])

if len(wikipedia.page(busqueda).images)>1:

    tb.send_message('id_bot', wikipedia.page(busqueda).images[1])

if len(wikipedia.page(busqueda).images)>2:

    tb.send_message('id_bot', wikipedia.page(busqueda).images[2])
